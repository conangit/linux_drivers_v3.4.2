#ifndef __LCDDRV_H
#define __LCDDRV_H

void jz2440_lcd_backlight(unsigned char n);			

void lcd_power_config( unsigned char lcd_pwrdn, unsigned char power_en );

void lcd_init(void);

#endif
