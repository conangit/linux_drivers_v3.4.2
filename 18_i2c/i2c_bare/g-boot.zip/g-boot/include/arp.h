typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

#define PROTO_ARP 	0x0806
#define PROTO_IP  	0x0800
#define PROTO_UDP  	0x11

//�����ֽ���--���ģʽ
#define HON(n)	((u16)(((n)&0xff)<<8 | ((n)&0xff00)>>8))

typedef struct eth_hdr
{
	u8 dmac[6];
	u8 smac[6];
	u16 type;	
}ETH_HDR;


typedef struct arp_hdr
{
	ETH_HDR ethhdr;
	u16 hwtype;
	u16 protocol;
	u8  hwlen;
	u8  protolen;
	u16 opcode;
	u8  smac[6];
	u8  sip[4];
	u8  dmac[6];
	u8  dip[4];
}ARP_HDR;

typedef struct ip_hdr
{
	ETH_HDR ethhdr;
	u8  vhl;
	u8  tos;
	u16 len;
	u16 ipid;
	u16 ipoffset;
	u8  ttl;
	u8  protocol;
	u16 ipchksum;
	u8 sip[4];
	u8 dip[4];	
}IP_HDR;


typedef struct udp_hdr
{
	IP_HDR iphdr;
	u16 sport;
	u16 dport;
	u16 len;
	u16 udpchksum;	
}UDP_HDR;

typedef struct tftp_package
{
	u16 opcode;
	u16 blocknum;
	u8  data[0];	
}TFTP_PACKAGE;


