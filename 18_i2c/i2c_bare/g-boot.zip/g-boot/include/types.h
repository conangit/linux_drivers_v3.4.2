
#ifndef _TPYES_H
#define _TPYES_H

#ifndef NULL
#define		NULL	0
#endif

#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif  /* _SIZE_T */


#endif /* _TPYES_H */
