
#ifndef _PRINTF_H
#define _PRINTF_H

int printf(const char *fmt, ...);
int scanf(const char * fmt, ...);

#endif /* _PRINTF_H */
