
//extern const unsigned char qq[90200];
//extern const unsigned char qigong[153000];


int gboot_main( )
{
    int ret;
    int num;
    
    uart_init();
    
    init_led();
    init_buttons();
    init_irq();
    
    //dma_init();
    //dma_start();
    
    //lcd_init();
    //lcd_clear();
    //lcd_line(150);
    //lcd_picture(0,0,220,205,qq);
    //lcd_picture24(0,0,300,170,qigong);
    //lcd_tpal();
    
    //ts_init();
    
    //dm9000_init();
    //do_arp();
   
    i2c_test();
    
    while(1);
    
    #if 0
    while(1)
    {
        printf("\r\n##################################################\r\n");
        printf("################### LIHONG-BOOT ##################\r\n");
        printf("\r\n[1]:发送arp请求\r\n");
        printf("[2]:Download Linux Kernel from PC tftp server.\r\n");
        printf("[3]:Boot Linux from RAM.\r\n");
        printf("[4]:Boot Linux from Nand flash.\r\n");
        printf("[5]:打开/关闭lcd背光\r\n");
        printf("\r\nPlease select:");
        
        scanf("%d",&num);
        
        switch( num )
        {
            case 1:
              arp_request();
            break;
            
            case 2:
              tftp_send_request("zImage_T35");
            break;
            
            case 3:
              boot_linux();
            break;
            
            case 4:
              //boot_linux_from_nand();
            break;
            
            case 5:
            {
              static int n = 1;
              
              if(n==1)
                n=0;
              else
                n=1;
                
              lcd_power_config(1,n);
              jz2440_lcd_backlight(n);
            }
            break;
            
            default:
              printf("Error:Please select 1-3\r\n");
            break;  
        }
    }
    #endif

    return 0;
}

