#define GPFCON	(*(volatile unsigned long *)0x56000050)
#define GPFDAT	(*(volatile unsigned long *)0x56000054)
#define GPFUP	(*(volatile unsigned long *)0x56000058)

#define GPGCON	(*(volatile unsigned long *)0x56000060)
#define GPGDAT	(*(volatile unsigned long *)0x56000064)
#define GPGUP	(*(volatile unsigned long *)0x56000068)

#define GPF0_msk  (3 << 0*2 )
#define GPF2_msk  (3 << 2*2 )

#define GPG3_msk  (3 << 3*2 )
#define GPG11_msk (3 << 11*2)


#define INT0 	(0b10 << 0*2 )
#define INT2 	(0b10 << 2*2 )
#define INT11 	(0b10 << 3*2 )
#define INT19 	(0b10 << 11*2)

void init_buttons( void )
{
	GPFCON &= ~(GPF0_msk | GPF2_msk);
	GPFCON |= (INT0 | INT2);
	
	GPGCON &= ~(GPG3_msk | GPG11_msk);
	GPGCON |= (INT11 | INT19);		
}

