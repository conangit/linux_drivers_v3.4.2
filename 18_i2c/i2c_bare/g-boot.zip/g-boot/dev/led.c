#define GPFCON	(*(volatile unsigned long *)0x56000050)
#define GPFDAT	(*(volatile unsigned long *)0x56000054)
#define GPFUP	(*(volatile unsigned long *)0x56000058)

#define GPF4_msk  (3 << 4*2 )
#define GPF5_msk  (3 << 5*2 )
#define GPF6_msk  (3 << 6*2 )

#define GPF4_out  (1 << 4*2 )
#define GPF5_out  (1 << 5*2 )
#define GPF6_out  (1 << 6*2 )


void init_led( void )
{
	GPFCON &= ~(GPF4_msk | GPF5_msk | GPF6_msk);
	GPFCON |= (GPF4_out | GPF5_out | GPF6_out);
	GPFDAT = 0xff;
}

void led_on( void )
{
	GPFDAT = 0x8f;
}

void led_off( void )
{
	GPFDAT = 0xff;
}

void led_on_1( void )
{
	GPFDAT = 0xef;
}

void led_on_2( void )
{
	GPFDAT = 0xdf;
}

void led_on_3( void )
{
	GPFDAT = 0xbf;
}


