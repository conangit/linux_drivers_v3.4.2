#define GPHCON 		(*(volatile unsigned long *)0x56000070)

#define ULCON0 		(*(volatile unsigned long *)0x50000000)
#define UCON0  		(*(volatile unsigned long *)0x50000004)
#define UBRDIV0		(*(volatile unsigned long *)0x50000028)
#define UTRSTAT0	(*(volatile unsigned long *)0x50000010)
#define UTXH0		(*(volatile unsigned long *)0x50000020)
#define URXH0		(*(volatile unsigned long *)0x50000024)


#define GPH2_msk 	(3 << 2*2)
#define GPG3_msk 	(3 << 3*2)

#define RXD0 		(0b10 << 3*2)
#define TXD0 		(0b10 << 2*2)

#define PCLK 		50000000
#define UART_BAUD_RATE 	115200
#define UART_BRD 	((int)(PCLK/(UART_BAUD_RATE*16)-1))


void uart_init( void )
{
	//1.������������RXD0,TXD0
	GPHCON &= ~(GPH2_msk | GPG3_msk);
	GPHCON |= (RXD0 | TXD0);
	
	//2.1�������ݸ�ʽ
	ULCON0 = 0x03; 		//8-N-1
	
	//2.2���ù���ģʽ
	//UCON0 = 0b0101;		//��ѯ��ʽ
	UCON0 = 0b1010;		//DMA0ģʽ--ʵ�����ĸ������ڣ�δ�л����ڵĹ���ģʽ
	
	//3.���ò�����	
	UBRDIV0 = UART_BRD;	//115200
}

void putc( unsigned char ch )
{
	while( !(UTRSTAT0 & (1<<2)) );
	UTXH0 = ch;	
}

unsigned char getc( void )
{
	unsigned char ch;
	
	while( !(UTRSTAT0 & (1<<0)) );
	ch = URXH0;
	
	if( (ch == 0x0d) || (ch == 0x0a) )
	{
		putc(0x0d);
		putc(0x0a);		
	}
	else
		putc(ch);
		
	return ch;
}

void uart_send_string( char *str )
{
	while( *str )
	{
		putc( *str++);	
	}
	putc(0x0d);
	putc(0x0a);	
}

