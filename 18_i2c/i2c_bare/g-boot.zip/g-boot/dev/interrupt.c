/*��ʼ���жϿ�����*/
#define SRCPND 		(*(volatile unsigned long *)0x4a000000)
#define INTMSK 		(*(volatile unsigned long *)0x4a000008)
#define PRIORITY	(*(volatile unsigned long *)0x4a00000c)
#define INTPND		(*(volatile unsigned long *)0x4a000010)
#define INTOFFSET	(*(volatile unsigned long *)0x4a000014)


#define EINTPEND	(*(volatile unsigned long *)0x560000a8)
#define EINTMASK	(*(volatile unsigned long *)0x560000a4)

#define GPBDAT 		(*(volatile unsigned long *)0x56000014)

void init_irq( void )
{
	EINTMASK &= ~((1<<11) | (1<<19));		    //ʹ��eint11,eint19
	
	INTMSK &= ~((1<<0) | (1<<2) | (1<<5));		//ʹ��eint0,eint2,eint8_23
						
	__asm__(
	  "mrs r0,cpsr\n"
	  "bic r0,#0x80\n"				//bit7 ��Ϊ0
	  "msr cpsr_c,r0\n"				//cpsr��bit0-7���ڿ���λ
	  :
	  :
	);
}


void HandleIRQ( void )
{
	unsigned long irq_oft = INTOFFSET;
	unsigned long irq_val;
	
	/*�ж��ж�Դ*/
	switch( irq_oft )
	{
		case 0:
		  led_off();
		  led_on_1();	
		break;
		
		case 2:
		  led_off();
		  led_on_2();
		break;
		
		case 5:
		  irq_val = EINTPEND;
		  
		  if( irq_val&(0x1<<11) )
		  {
		  	led_off();
		  	led_on_3();	
		  }
		  if( irq_val&(0x1<<19) )
		  {
		  	led_off();
		  }	
		break;
		
		case 31:
		  handle_tsirq();
		break;
		  
		case 4:
		  irq_val = EINTPEND;
		  
		  if( irq_val&(0x1<<7) )
		  {
		     int_issue();
		  } 		
		break;
        
        case 27:
            handle_i2cirq();
        break;
		
		default:
		  break;
	}
	
	/*��������ж�*/
	if( irq_oft == 5)
	{
		EINTPEND |= (1<<11) | (1<<19);
	}
    
    if( irq_oft == 4)
	{
		EINTPEND |= (1<<7);
	}
    
	SRCPND |= (1 << irq_oft);
	INTPND |= (1 << irq_oft);		
}

