#include "dm9000.h"
#include "arp.h"

//typedef unsigned char u8;
//typedef unsigned short u16;
//typedef unsigned long u32;

#define SRCPND 		(*(volatile unsigned long *)0x4a000000)
#define INTMSK 		(*(volatile unsigned long *)0x4a000008)
#define PRIORITY	(*(volatile unsigned long *)0x4a00000c)
#define INTPND		(*(volatile unsigned long *)0x4a000010)
#define INTOFFSET	(*(volatile unsigned long *)0x4a000014)
#define EINTMASK	(*(volatile unsigned long *)0x560000a4)
#define EINTPEND	(*(volatile unsigned long *)0x560000a8)
#define EXTINT0		(*(volatile unsigned long *)0x56000088)
 

#define BWSCON		(*(volatile unsigned long *)0x48000000)
#define BANKCON4	(*(volatile unsigned long *)0x48000014)

#define GPFCON		(*(volatile unsigned long *)0x56000050)

#define DM_ADD		(*(volatile unsigned short *)0x20000300)
#define DM_DAT		(*(volatile unsigned short *)0x20000304)

#define B4_Tacs			0x0		/*  0clk */
#define B4_Tcos			0x0		/*  3clk */
#define B4_Tacc			0x7		/* 14clk */
#define B4_Tcoh			0x1		/*  1clk */
#define B4_Tah			0x0		/*  0clk */
#define B4_Tacp			0x0 		/*  6clk */
#define B4_PMC			0x0		/* normal */

#define PIK_MAX_LEN		1522		/* ��̫��������󳤶�*/

u8 dm9000_mac_addr[6] = {0x11,0x55,0x22,0x44,0x33,0xee};
u8 dm9000_ip[4] = {192,168,3,151};

u8 host_mac_adr[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
u8 host_ip[4] = {192,168,3,243};

static void cs_init()
{
	BWSCON &= ~(3 << 16);
	BWSCON |= (1 << 16);

	BANKCON4 = (B4_Tacs<<13) | (B4_Tcos<<11) | (B4_Tacc<<8) | (B4_Tcoh<<6) | (B4_Tah<<4) | (B4_Tacp<<2) | (B4_PMC); 
}


static void int_init()
{
	//EINT7-GPF7
	GPFCON &= ~(3 << 14);
	GPFCON |= (2 << 14);

	//�ߵ�ƽ����
	EXTINT0 &= ~(7 << 28);
	EXTINT0 |= (1 << 28);

	//ʹ���ⲿ�ж�EINT7
	INTMSK &= ~(1 << 4);
	EINTMASK &= ~(1 << 7);

	//����жϱ�־λ
	EINTPEND |= (1 << 7);
	SRCPND |= (1 << 4);
	INTPND |= (1 << 4);
}

/*
 * u16 reg -- �Ĵ���ƫ��
 * u16 data -- IO������
 */

void dm9000_reg_write( u16 reg, u16 data )
{
	DM_ADD = reg;
	DM_DAT = data;
}

u8 dm9000_reg_read( u16 reg )
{
	DM_ADD = reg;
	return DM_DAT;
}


static void dm9000_reset()
{
	/* DEBUG: Make all GPIO0 outputs, all others inputs */
	dm9000_reg_write(DM9000_GPCR, GPCR_GPIO0_OUT);
	/* Step 1: Power internal PHY by writing 0 to GPIO0 pin */
	dm9000_reg_write(DM9000_GPR, 0);
	
	/* Step 2: Software reset 10us  */
	dm9000_reg_write(DM9000_NCR, (NCR_LBK_INT_MAC | NCR_RST));
	dm9000_reg_write(DM9000_NCR, 0);

	dm9000_reg_write(DM9000_NCR, (NCR_LBK_INT_MAC | NCR_RST)); 
	dm9000_reg_write(DM9000_NCR, 0);
}

int dm9000_probe()
{
	u32 id_val;

	id_val = dm9000_reg_read(DM9000_VIDL);
	id_val |= dm9000_reg_read(DM9000_VIDH) << 8;
	id_val |= dm9000_reg_read(DM9000_PIDL) << 16;
	id_val |= dm9000_reg_read(DM9000_PIDH) << 24;
	
	if (id_val == DM9000_ID)
	{
		printf("\r\n dm9000 is found. \r\n");
		printf("\r\n dm9000_ID = 0X%08X. \r\n", id_val);
		return 0;
	}
	else
	{
		printf("\r\n dm9000 not found. \r\n");
		return -1;
	}
}


static void mac_init()
{
	/* Program operating register, only internal phy supported */
	dm9000_reg_write(DM9000_NCR, 0x0);
	/* TX Polling clear */
	dm9000_reg_write(DM9000_TCR, 0);
	/* Less 3Kb, 200us */
	dm9000_reg_write(DM9000_BPTR, BPTR_BPHW(3) | BPTR_JPT_600US);
	/* Flow Control : High/Low Water */
	dm9000_reg_write(DM9000_FCTR, FCTR_HWOT(3) | FCTR_LWOT(8));
	/* SH FIXME: This looks strange! Flow Control */
	dm9000_reg_write(DM9000_FCR, 0x0);
	/* Special Mode */
	dm9000_reg_write(DM9000_SMCR, 0);
	/* clear TX status */
	dm9000_reg_write(DM9000_NSR, NSR_WAKEST | NSR_TX2END | NSR_TX1END);
	/* Clear interrupt status */
	dm9000_reg_write(DM9000_ISR, ISR_ROOS | ISR_ROS | ISR_PTS | ISR_PRS);
}



void dm9000_init()
{
	u8 i;
	
	//����Ƭѡ
	cs_init();

	//�жϳ�ʼ��
	int_init();

	//��λ�豸
	dm9000_reset();

	//����dm9000
	dm9000_probe();

	//MAC��ʼ��
	mac_init();

	//���MAC ��ַ
	for (i = 0; i < 6; i++)
	{
		dm9000_reg_write(DM9000_PAR+i, dm9000_mac_addr[i]);
	}
	
	//����dm9000
	/* RX enable */
	/* ��������Ϊ���ܹ㲥�� RCR_ALL */
	dm9000_reg_write( DM9000_RCR, RCR_DIS_LONG | RCR_DIS_CRC | RCR_RXEN );
	/* Enable TX/RX interrupt mask */
	dm9000_reg_write(DM9000_IMR, IMR_PAR);
}


void dm9000_tx(u8 *data, u32 length)
{
	u32 i;

	//��ֹ�ж�
	dm9000_reg_write(DM9000_IMR, 0x80);

	//д�뷢�����ݵĳ���
	dm9000_reg_write(DM9000_TXPLL, length & 0xff);
	dm9000_reg_write(DM9000_TXPLH, (length >> 8) & 0xff);

	//д������͵�����
	DM_ADD = DM9000_MWCMD;
	
	for(i=0; i<length; i+=2)
	{
		DM_DAT = data[i] | (data[i+1]<<8);
	}
	
	//��������
	dm9000_reg_write(DM9000_TCR, TCR_TXREQ); 	/* Cleared after TX complete */
	
	//�ȴ����ͽ���
	while(1)
	{
		u8 status;

		status = dm9000_reg_read(DM9000_TCR);
		if( (status&0x01) == 0x00 )
			break;
	}

	//�������״̬
	dm9000_reg_write(DM9000_NSR, 0x2c);
	
	//�ָ��ж�ʹ��
	dm9000_reg_write(DM9000_IMR, 0x81);

}


int dm9000_rx(u8 *data)
{
	u32 i;
	u16 tmp;
	
	//u8 status;		/*ע��dm9000оƬ����*/
	//u32 length;
	u16 status,length;
	
	u8 ready = 0;
	
	//�ж��Ƿ�����жϣ������
	if( (dm9000_reg_read(DM9000_ISR) & 0x01) )
	{
		dm9000_reg_write(DM9000_ISR, 0x01);
	}
	else
	{
		return -1;
	}
	
	//�ն�һ��
	ready = dm9000_reg_read(DM9000_MRCMDX);
	
	if( (ready&0x01) != 0x01 )
	{
		ready = dm9000_reg_read(DM9000_MRCMDX);
		if( (ready&0x01) != 0x01 )
		{
			return 0;
		}	
	}

	//��ȡ״̬
	status = dm9000_reg_read(DM9000_MRCMD);
	
	//��ȡ������
	length = DM_DAT;

	//��ȡ������
	if( length < PIK_MAX_LEN )
	{
		for(i=0; i<length; i+=2)
		{
			tmp = DM_DAT;
			data[i] = tmp&0xff;
			data[i+1] = (tmp>>8)&0xff;
		}
		return length;
	}
}



void int_issue()
{
	u8 netbuf[1500];
   	int packet_rx_len;

	packet_rx_len = dm9000_rx(&netbuf[0]);
	
	net_handle(&netbuf[0], packet_rx_len);
	
	EINTPEND |= (1 << 7);
	SRCPND |= (1 << 4);
	INTPND |= (1 << 4);	
}



